  $(function() {
    $("#playlist1 li").on("click", function() {
        $("#videoarea1").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea1").attr({
        "src": $("#playlist1 li").eq(0).attr("movieurl"),
        "poster": $("#playlist1 li").eq(0).attr("moviesposter")
    })
})

/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */


   $(function() {
    $("#playlist2 li").on("click", function() {
        $("#videoarea2").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea2").attr({
        "src": $("#playlist2 li").eq(0).attr("movieurl"),
        "poster": $("#playlist2 li").eq(0).attr("moviesposter")
    })
})

/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */


   $(function() {
    $("#playlist3 li").on("click", function() {
        $("#videoarea3").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea3").attr({
        "src": $("#playlist3 li").eq(0).attr("movieurl"),
        "poster": $("#playlist3 li").eq(0).attr("moviesposter")
    })
})


/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

   $(function() {
    $("#playlist4 li").on("click", function() {
        $("#videoarea4").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea4").attr({
        "src": $("#playlist4 li").eq(0).attr("movieurl"),
        "poster": $("#playlist4 li").eq(0).attr("moviesposter")
    })
})

/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

   $(function() {
    $("#playlist5 li").on("click", function() {
        $("#videoarea5").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea5").attr({
        "src": $("#playlist5 li").eq(0).attr("movieurl"),
        "poster": $("#playlist5 li").eq(0).attr("moviesposter")
    })
})

   /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

   $(function() {
    $("#playlist6 li").on("click", function() {
        $("#videoarea6").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea6").attr({
        "src": $("#playlist6 li").eq(0).attr("movieurl"),
        "poster": $("#playlist6 li").eq(0).attr("moviesposter")
    })
})


   /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

   $(function() {
    $("#playlist7 li").on("click", function() {
        $("#videoarea7").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea7").attr({
        "src": $("#playlist7 li").eq(0).attr("movieurl"),
        "poster": $("#playlist7 li").eq(0).attr("moviesposter")
    })
})


   /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

   $(function() {
    $("#playlist8 li").on("click", function() {
        $("#videoarea8").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea8").attr({
        "src": $("#playlist8 li").eq(0).attr("movieurl"),
        "poster": $("#playlist8 li").eq(0).attr("moviesposter")
    })
})



